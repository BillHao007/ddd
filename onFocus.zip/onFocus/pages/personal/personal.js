var app = getApp();
Page({
    data:{
        bgColor:"1aad19"
    },
    onShow: function(){
        this.setData({
            bgColor: app.globalData.themeColor
        })
        wx.setNavigationBarColor({
            frontColor:"#ffffff",
            backgroundColor: app.globalData.themeColor,
            animation:{}
        });
    }
})