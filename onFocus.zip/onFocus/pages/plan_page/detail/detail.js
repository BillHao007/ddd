Page({
    data:{
        id: 0
    },

    onLoad: function(){
        var pages = getCurrentPages();
        var lastPage = pages[pages.length - 2];
        this.setData({
            id: lastPage.data.tapId
        })
    },

    onShow: function(){
        
    }
})