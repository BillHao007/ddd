var app = getApp();
Page({
    data:{
        themeColor: "1aad19",   //主题色
        globalEmpty:true,    //用于控制empty-demo是否展示
        todayTask: 10,
        finish: 5,
        focusTime: 400,
        planList: new Array(),    //计划表
        tapId:0,                 //用于存储被点击的表单的id值
        type: "waiting"              //board右下icon的类型
    },

    onLoad: function(){
        this.setData({
            statusBarHeight: app.globalData.statusHeight,  
            //获得顶部状态栏的高度
            screenHeight: app.globalData.screenHeight,
            themeColor: app.globalData.themeColor,
            windowHeight: app.globalData.windowHeight,

        });
    },

    onShow: function(){
        /*以下if语句用来更改任务栏为空时的展示效果*/ 
        if(this.data.planList.length == 0)
            this.setData({
                bgChangeForGlobal: "global-page-gray",
                globalEmpty:true
            })
        else
            this.setData({
                bgChangeForGlobal: "",
                globalEmpty:false
            })
        this.setData({
            themeColor:app.globalData.themeColor
        })
    },

    newBoard: function(){
        wx.navigateTo({
            url: "/pages/plan_page/new_plan/new_plan"
        })
    },

    /*展示计划详请页面*/
    toDetail: function(event){
        var id = event.currentTarget.id;
        this.setData({
            tapId: id   /*选择计划的id*/
        });
        wx.navigateTo({
            url: "/pages/plan_page/detail/detail"
        })
    },

    /*选择删除*/
    selectToDelete: function(){
        this.setData({
            selectedClass: "selected-board",
            selected: true
        })
    }
})