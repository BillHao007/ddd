var app = getApp()
var util = require('../../../utils/utils.js');
Page({
    data:{
        pageId: 0,
        tabBarStyleList: new Array(),
        startTime: "00:00",  /*开始时间picker绑定的数据*/
        focusTime: "0分钟",   /*专注时长picker绑定的数据*/
        remindTime: "00:00",  /*提醒picker绑定的数据*/
        startDate: "2019-01-01",
        endDate:"2019-01-01",
        isRemindPickerDisplay: false,
        levelType: "从高到低",
        levelArray:["十万火急","刻不容缓","迫不及待","拭目以待","从容不迫","不慌不忙","稳住能赢","若无其事"],
        isLevelPickerDisplay: false
    },
    onLoad: function(){
        var date = util.formatTime(new Date())
        console.log(date);
        this.setData({
            themeColor: app.globalData.themeColor
        })
    },
 
    onShow: function(){
        this.setData({
            "tabBarStyleList[0]":
            "border-bottom:6rpx solid #"+this.data.themeColor+";color:#"+this.data.themeColor
        })
    },

    submit: function(){
        var pages = getCurrentPages();
        var lastPage = pages[pages.length - 2];
        var list = lastPage.data.planList;
        list.push("");
        lastPage.setData({
            planList: list
        })
        wx.navigateBack({
            delta: 1
        })
    },
    changePage: function(event){
        var id = event.currentTarget.id;
        var style = "tabBarStyleList["+id+"]";
        this.setData({
            tabBarStyleList:  new Array(),
            [style]: "border-bottom:6rpx solid #"+this.data.themeColor+";color:#"+this.data.themeColor,
            pageId: id
        });
    },

    /*时间选择器绑定的函数，更改时间值*/
    timePickerChange: function(event){
        this.setData({
            startTime: event.detail.value
        })
    },

    focusPickerChange: function(event){
        var time = event.detail.value;
        var hour, min;
        if(time[0] == "0") hour = time[1];
        else hour = time[0] + time[1];
        if(time[3] == "0") min = time[4];
        else min = time[3] + time[4];
        if(parseInt(min) < 5 && hour != "00")
        {
            wx.showModal({
                title:"您还不够专注哦！",
                content:"专注时长不得低于5分钟，您可以通过设置备忘来提醒短时事宜",
                showCancel:false
            })
            return;
        }
        if(hour == "0")
        {
            this.setData({
                focusTime: min+"分钟"
            })
        }
        else
            this.setData({
                focusTime: hour+"小时"+min+"分钟"
            })
        
    },
    remindPickerChange: function(event){
        this.setData({
            remindTime: event.detail.value
        })
    },

    controlRemindPicker: function(event){
        this.setData({
            isRemindPickerDisplay: event.detail.value
        })
    },

    levelPickerChange: function(event){
        var index = event.detail.value
        this.setData({
            levelType: this.data.levelArray[index]
        })
    },

    controlLevelPicker: function(event){
        this.setData({
            isLevelPickerDisplay: event.detail.value
        })
    }
})